# NOMBRE: *Jeronimo Colorado Soto*

## CLAN: **Tesla**

## CORREO: °°°*jeroto2410@gmail.com*°°°

### DOCUMENTO DE IDENTIDAD: **1041229803**

#### CONTACTO SEGURO: *3016839348*

##### En la seccion de About me. Podras observar Que es lo que me apasiona y a que quiero aspirar en unos años, mas abajo podras ver mis habilidades tecnicas hasta el dia de hoy.

###### En la seccion de proyectos ("Projects") podras observar mis creaciones completadas hasta el dia de hoy y podras ver con que lenguajes de programacion los hice.

###### ° En la seccion de contacto ("Contact") podras dejar tu informacion para comunicarme contigo en cualquier momento. Si no quieres esperar mi respuesta puedes encontrarme en mis enlaces directos para mis redes sociales y mis perfiles de contacto laboral. TE AGRADEZCO LA ATENCION. :)
